# TeaTapler — Free Luxury Brand Website (Astro)

## What this is
A fast, luxury-style TeaTapler site built in Astro (static) with:
- Home, Collections, Product pages
- Pre-order landing page
- Experience + Journal
- Private Portal (/portal) for wholesale/investor/media assets

## Local run
1) Install Node.js (LTS)
2) In this folder:
   - npm install
   - npm run dev

## Deploy free (recommended): Cloudflare Pages
- Connect this GitHub repo to Cloudflare Pages
- Framework preset: Astro
- Build command: npm run build
- Output directory: dist

## Protect /portal (admin access) for free
Use Cloudflare Zero Trust Access:
- Create Access Application for teatapler.com/portal*
- Allow only approved emails (you + partners/investors)
- Everyone else blocked

## Edit content quickly
- Brand text: src/content/brand.json
- Products: src/content/products.json

## Replace the logo
Replace public/logo.png with your actual TeaTapler logo.
