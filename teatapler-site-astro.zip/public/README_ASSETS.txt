Replace public/logo.png with your TeaTapler logo (PNG). Add favicon.ico if you want.
