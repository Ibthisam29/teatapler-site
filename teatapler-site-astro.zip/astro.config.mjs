import { defineConfig } from 'astro/config';

export default defineConfig({
  site: 'https://teatapler.com',
});
